defmodule ProjectWeb.ItemsView do
  use ProjectWeb, :view
end
