defmodule ProjectWeb.LayoutView do
  use ProjectWeb, :view
end
